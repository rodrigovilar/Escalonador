package br.ufpb.dcx.aps.escalonador;

public enum TipoEscalonador {
	RoundRobin, Prioridade, MaisCurtoPrimeiro
}
